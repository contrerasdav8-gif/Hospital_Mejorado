<?php
session_start();
include("Config/conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM usuarios WHERE usuario = ?";

    $stmt = mysqli_prepare($conexion, $sql);

    mysqli_stmt_bind_param($stmt, "s", $usuario);

    mysqli_stmt_execute($stmt);

    $resultado = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($resultado) == 1){

        $datos = mysqli_fetch_assoc($resultado);

        // Contraseña en texto plano
        if($datos['password'] == $password){

            $_SESSION['id'] = $datos['id'];
            $_SESSION['usuario'] = $datos['usuario'];
            $_SESSION['nombre'] = $datos['nombre'];
            $_SESSION['rol'] = $datos['rol'];

            switch($datos['rol']){

                case "Administrador":
                    header("Location: Admin/dashboard.php");
                    exit();

                case "Doctor":
                    header("Location: Doctor/dashboard.php");
                    exit();

                case "Paciente":
                    header("Location: Paciente/dashboard.php");
                    exit();

                default:
                    echo "<script>
                    alert('Rol no válido');
                    window.location='index.php';
                    </script>";
                    exit();
            }

        }else{

            echo "<script>
            alert('Contraseña incorrecta');
            window.location='index.php';
            </script>";
        }

    }else{

        echo "<script>
        alert('El usuario no existe');
        window.location='index.php';
        </script>";

    }

}else{

    header("Location:index.php");
    exit();

}
?>