<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Hospital DB SaMy</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>

body{
background:linear-gradient(135deg,#0d6efd,#20c997);
height:100vh;
display:flex;
justify-content:center;
align-items:center;
font-family:Arial;
}

.card{
width:430px;
border:none;
border-radius:20px;
box-shadow:0 20px 40px rgba(0,0,0,.25);
}

.logo{
font-size:65px;
color:#0d6efd;
}

</style>

</head>

<body>

<div class="card p-4">

<div class="text-center">

<div class="logo">
<i class="bi bi-hospital"></i>
</div>

<h2 class="fw-bold text-primary">
Hospital DB SaMy
</h2>

<p class="text-muted">
Sistema de Gestión Hospitalaria
</p>

</div>

<form action="login.php" method="POST">

<div class="mb-3">

<label class="form-label">

Usuario

</label>

<input
type="text"
name="usuario"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">

Contraseña

</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<button class="btn btn-primary w-100">

<i class="bi bi-box-arrow-in-right"></i>

Iniciar Sesión

</button>

</form>

<hr>

<div class="text-center">

<b>Proyecto:</b>

Sistema de Gestión Hospitalaria

<br>

<b>Desarrollador:</b>

David Constantino Contreras

</div>

</div>

</body>

</html>